package repository;

import model.Student;

public interface IStudentRepository extends ICrudRepository<Student> {
}
