/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Hquyen
 */
public class Magazine {
    // Attributes of the Magazine class
    private String magID;
    private String magazineTitle;
    private String publisher;
    private double price;

    // Constructor
    public Magazine() {
    }

    public Magazine(String magID, String magazineTitle, String publisher, double price) {
        this.magID = magID;
        this.magazineTitle = magazineTitle;
        this.publisher = publisher;
        this.price = price;
    }

    // Getters and setters for each attribute
    public String getMagID() {
        return magID;
    }

    public void setMagID(String magID) {
        this.magID = magID;
    }

    public String getMagazineTitle() {
        return magazineTitle;
    }

    public void setMagazineTitle(String magazineTitle) {
        this.magazineTitle = magazineTitle;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
