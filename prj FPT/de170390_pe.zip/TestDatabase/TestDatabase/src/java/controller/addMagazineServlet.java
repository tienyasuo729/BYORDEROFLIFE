/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Magazine;
import Repository.MagazineDB;

/**
 *
 * @author Hquyen
 */
public class addMagazineServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet addMagazineServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet addMagazineServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("Magazine.jsp").forward(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Nhận dữ liệu từ request
        // Nhận dữ liệu từ request
        String magID = request.getParameter("magID");
        String magazineTitle = request.getParameter("magazineTitle");
        String publisher = request.getParameter("publisher");
        String priceStr = request.getParameter("price"); // Nhận giá trị giá dưới dạng String

        double price = 0; // Khởi tạo mặc định
        if (priceStr != null && !priceStr.trim().isEmpty()) {
            try {
                price = Double.parseDouble(priceStr.trim()); // Chuyển đổi chuỗi sang double
            } catch (NumberFormatException e) {
                request.setAttribute("errorMessage", "Giá không hợp lệ. Vui lòng nhập một số.");
                RequestDispatcher dispatcher = request.getRequestDispatcher("Magazine.jsp");
                dispatcher.forward(request, response);
                return;
            }
        } else {
            request.setAttribute("errorMessage", "Vui lòng nhập giá cho tạp chí.");
            RequestDispatcher dispatcher = request.getRequestDispatcher("Magazine.jsp");
            dispatcher.forward(request, response);
            return;
        }
        // Tạo một đối tượng Magazine mới
        Magazine magazine = new Magazine(magID, magazineTitle, publisher, price);
        boolean insertResult = MagazineDB.addNew(magazine);

        if (insertResult) {
            request.setAttribute("newMagazine", magazine);
            RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
            dispatcher.forward(request, response);
        } else {
            request.setAttribute("errorMessage", "Có lỗi khi thêm tạp chí mới");
            RequestDispatcher dispatcher = request.getRequestDispatcher("error_page.jsp");
            dispatcher.forward(request, response);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
