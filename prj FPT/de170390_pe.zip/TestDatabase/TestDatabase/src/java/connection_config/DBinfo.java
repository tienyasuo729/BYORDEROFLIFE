/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package connection_config;

/**
 *
 * @author PC
 */
public interface DBinfo {

    String dbURL = "jdbc:sqlserver://LAPTOP-NEMDVCRB\\MSSQLHQ:1433;databaseName=PRJ321_DE170390;characterEncoding=UTF-8";
    String dbUser="root";
    String dbPass="12345";
    String driver="com.microsoft.sqlserver.jdbc.SQLServerDriver";
}
