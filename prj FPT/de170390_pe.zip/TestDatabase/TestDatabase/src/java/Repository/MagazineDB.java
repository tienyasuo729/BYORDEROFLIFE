/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Repository;

import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import connection_config.DBinfo;
import model.Magazine;

/**
 * Data Access Object for the Magazine table.
 */
public class MagazineDB implements DBinfo {

    public MagazineDB() {
        try {
            Class.forName(driver);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(MagazineDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public ArrayList<Magazine> getAll() {
        ArrayList<Magazine> magazines = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(dbURL, dbUser, dbPass);
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM Magazine_DE170390");
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                String magID = rs.getString("MagID");
                String title = rs.getString("MagazineTitle");
                String publisher = rs.getString("Publisher");
                double price = rs.getDouble("Price");
                magazines.add(new Magazine(magID, title, publisher, price));
            }
        } catch (SQLException ex) {
            Logger.getLogger(MagazineDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        return magazines;
    }

    public static boolean addNew(Magazine m) {
        try (Connection conn = DriverManager.getConnection(dbURL, dbUser, dbPass);
             PreparedStatement ps = conn.prepareStatement("INSERT INTO Magazine_DE170390 (MagID, MagazineTitle, Publisher, Price) VALUES (?, ?, ?, ?)")) {

            ps.setString(1, m.getMagID());
            ps.setString(2, m.getMagazineTitle());
            ps.setString(3, m.getPublisher());
            ps.setDouble(4, m.getPrice());
            int i = ps.executeUpdate();
            return i > 0;
        } catch (SQLException ex) {
            Logger.getLogger(MagazineDB.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
}

