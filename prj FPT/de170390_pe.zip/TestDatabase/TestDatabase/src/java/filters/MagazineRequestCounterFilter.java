package filters;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.annotation.WebFilter;
import java.io.IOException;

@WebFilter("/Magazine.jsp") // Đảm bảo URL pattern này phù hợp
public class MagazineRequestCounterFilter implements Filter {
    private int hitCount; // Lưu số lượng request

    @Override
    public void init(FilterConfig fConfig) throws ServletException {
        hitCount = 0; // Khởi tạo biến đếm
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        hitCount++; // Tăng số lần truy cập mỗi lần có request
        request.getServletContext().setAttribute("hitCount", hitCount); // Lưu vào context để tất cả các request đều có thể truy cập
        chain.doFilter(request, response); // Tiếp tục xử lý request
    }

    @Override
    public void destroy() {
        // Không cần triển khai
    }
}

